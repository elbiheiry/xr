<?php
return [
    'details' => 'More details',
    'know' => 'Know More About Us',
    'view' => 'View more',
    'testimonials' => 'TESTIMONIALS',
    'work' => 'WORK PROCESS',
    'feedback' => 'Our client\'s feedback',
    'related_solutions' => 'Related Solutions',
    'hear' => 'We Would Like To Hear From You Anytime',
    'call' => 'Call us',
    'whats' => 'Whatsapp number',
    'email' => 'Email us',
    'visit' => 'Visit us'
];