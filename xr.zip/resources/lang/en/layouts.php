<?php 
    return [
        'home' => 'Home',
        'about' => 'About',
        'who_we_are' => 'Who We are',
        'partners' => 'Our Partners',
        'solutions' => 'Solutions',
        'articles' => 'Articles',
        'team' => 'Team',
        'contact_header' => 'Contact',
        'quick' => 'Quick links',
        'newsletter' => 'Subscribe Newsletter',
        'subscribe' => 'Subscribe',
        'email' => 'Enter your email',
        'talk' => 'let\'s talk',
        'contact' => 'Contact Information',
        'ready' => 'Ready to Get Started ?',
        'send' => 'Send Message'
    ];
?>