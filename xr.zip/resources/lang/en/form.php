<?php 

return [
    'name' => 'Your name',
    'email' => 'Your email address',
    'phone' => 'Your phone number',
    'message' => 'Write your message',
    'wait' => 'Please wait',
    'subject' => 'You subject'
];