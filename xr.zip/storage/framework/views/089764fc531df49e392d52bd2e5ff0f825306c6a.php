
<?php $__env->startSection('content'); ?>
    <!-- Start Page Banner Area -->
    <div class="page-banner-area bg-5 jarallax" data-jarallax='{"speed": 0.3}'>
        <div class="container">
            <div class="page-banner-content" data-aos="fade-right" data-aos-delay="50" data-aos-duration="500"
                data-aos-once="true">
                <h2><?php echo e(__('layouts.team')); ?></h2>

                <ul>
                    <li>
                        <a href="<?php echo e(route('site.index')); ?>"><?php echo e(__('layouts.home')); ?></a>
                    </li>
                    <li><?php echo e(__('layouts.team')); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Page Banner Area -->

    <!-- Start Team Area -->
    <div class="team-area pt-100 pb-75 white_bc">
        <div class="container">
            <div class="section-title section-style-two">
                <span><?php echo e(__('layouts.team')); ?></span>
                <h2><?php echo $content->translate(app()->getLocale())->title4; ?> <span class="overlay"></span></h2>
                <p>
                    <?php echo $content->translate(app()->getLocale())->description4; ?>

                </p>
            </div>

            <div class="row justify-content-center">
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6">
                        <div class="single-team-card">
                            <div class="team-image" data-tilt>
                                <img src="<?php echo e(get_image($member->image, 'members')); ?>" alt="image" />
                                <?php if(isset($member->links)): ?>
                                    <ul class="team-social">
                                        <?php $__currentLoopData = $member->links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e($link->link); ?>" target="_blank">
                                                    <?php echo $link->icon; ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>

                            </div>
                            <div class="team-content">
                                <h3><?php echo e($member->translate(app()->getLocale())->name); ?></h3>
                                <span> <?php echo e($member->translate(app()->getLocale())->position); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="team-shape">
            <img src="<?php echo e(surl('images/team/line-shape.png')); ?>" alt="image" />
        </div>
    </div>
    <!-- End Team Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xr\resources\views/site/pages/team/index.blade.php ENDPATH**/ ?>