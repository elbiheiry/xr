
<?php $__env->startSection('content'); ?>
    <!-- Start Page Banner Area -->
    <div class="page-banner-area bg-5 jarallax" data-jarallax='{"speed": 0.3}'>
        <div class="container">
            <div class="page-banner-content" data-aos="fade-right" data-aos-delay="50" data-aos-duration="500"
                data-aos-once="true">
                <h2><?php echo e(__('layouts.partners')); ?></h2>

                <ul>
                    <li>
                        <a href="<?php echo e(route('site.index')); ?>"><?php echo e(__('layouts.home')); ?></a>
                    </li>
                    <li><?php echo e(__('layouts.partners')); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Page Banner Area -->
    <!-- Start Partner Area -->
    <div class="partner-area ptb-100 inner">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="partner-card" data-aos="fade-up" data-aos-delay="80" data-aos-duration="800"
                            data-aos-once="true">
                            <a href="#">
                                <img src="<?php echo e(get_image($partner->image, 'partners')); ?>" alt="partner" />
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xr\resources\views/site/pages/about/partners.blade.php ENDPATH**/ ?>