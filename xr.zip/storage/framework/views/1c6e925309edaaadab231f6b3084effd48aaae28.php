
<?php $__env->startSection('content'); ?>
    <!-- Start Page Banner Area -->
    <div class="page-banner-area bg-4 jarallax" data-jarallax='{"speed": 0.3}'>
        <div class="container">
            <div class="page-banner-content" data-aos="fade-right" data-aos-delay="50" data-aos-duration="500"
                data-aos-once="true">
                <h2><?php echo e($solution->translate(app()->getLocale())->title); ?></h2>

                <ul>
                    <li>
                        <a href="<?php echo e(route('site.index')); ?>"><?php echo e(__('layouts.home')); ?></a>
                    </li>
                    <li><?php echo e($solution->translate(app()->getLocale())->title); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Page Banner Area -->

    <!-- Start Services Details Area -->
    <div class="services-details-area ptb-100">
        <div class="container">
            <div class="services-details-desc">
                <div class="article-services-image">
                    <img src="<?php echo e(get_image($solution->inner_image, 'solutions')); ?>" alt="image" />
                </div>
                <div class="article-services-content">
                    <h3><?php echo e($solution->translate(app()->getLocale())->title); ?></h3>
                </div>
                <?php echo $solution->translate(app()->getLocale())->description; ?>

            </div>
        </div>

        <div class="services-details-shape">
            <img src="<?php echo e(surl('images/team/line-shape.png')); ?>" alt="image" />
        </div>
    </div>
    <!-- End Services Details Area -->

    <!-- Start Talk Area -->
    <!-- Start Services Area -->
    <div class="services-area with-radius ptb-100">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="services-section-content text-center" data-aos="fade-down" data-aos-delay="80"
                        data-aos-duration="800" data-aos-once="true">
                        <span><?php echo e(__('home.related_solutions')); ?></span>
                        <h3>
                            <?php echo $content->translate(app()->getLocale())->title2; ?>

                            <span class="overlay"></span>
                        </h3>
                        <p>
                            <?php echo $content->translate(app()->getLocale())->description2; ?>

                        </p>
                    </div>
                </div>
                <?php $__currentLoopData = $related_solutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_solution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="services-item">
                            <div class="services-image">
                                <a href="<?php echo e(route('site.solution', ['slug' => $related_solution->slug])); ?>"><img
                                        src="<?php echo e(get_image($related_solution->outer_image, 'solutions')); ?>"
                                        alt="image" /></a>
                            </div>
                            <div class="services-content">
                                <h3>
                                    <a
                                        href="<?php echo e(route('site.solution', ['slug' => $related_solution->slug])); ?>"><?php echo e($related_solution->translate(app()->getLocale())->title); ?></a>
                                </h3>
                                <p>
                                    <?php echo e($related_solution->translate(app()->getLocale())->brief); ?>

                                </p>
                                <a href="<?php echo e(route('site.solution', ['slug' => $related_solution->slug])); ?>"
                                    class="services-btn"><?php echo e(__('home.view')); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Start Talk Area -->
    <div class="talk-area ptb-100">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12">
                    <div class="talk-image" data-tilt>
                        <img src="<?php echo e(surl('images/talk.png')); ?>" alt="image" />
                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="talk-content margin-zero">
                        <span><?php echo e(__('layouts.talk')); ?></span>
                        <h3>
                            <?php echo e(__('home.hear')); ?>

                            <span class="overlay"></span>
                        </h3>

                        <form id="contactFormTwo" class="contact-form" method="post"
                            action="<?php echo e(route('site.contact.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="row">
                                <div class="col-lg-12 col-md-12">
                                    <div class="form-group">
                                        <input type="text" name="name" class="form-control"
                                            placeholder="<?php echo e(__('form.name')); ?>" />
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="email" name="email" class="form-control"
                                            placeholder="<?php echo e(__('form.email')); ?>" />
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="number" name="phone" class="form-control"
                                            placeholder="<?php echo e(__('form.phone')); ?>" />

                                    </div>
                                </div>

                                <div class="col-lg-12 col-md-12">
                                    <div class="form-group">
                                        <textarea name="message" class="form-control" cols="30" rows="6"
                                            placeholder="<?php echo e(__('form.message')); ?>..."></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 form-group">
                                    <div class="g-recaptcha" data-sitekey="6Lf4diYgAAAAAJZx1TBAoJeybyVXeATgcT7AX4NY"
                                        style="width:100px;">
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12">
                                    <button type="submit" class="default-btn">
                                        <?php echo e(__('layouts.send')); ?><span></span>
                                    </button>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xr\resources\views/site/pages/solutions/index.blade.php ENDPATH**/ ?>