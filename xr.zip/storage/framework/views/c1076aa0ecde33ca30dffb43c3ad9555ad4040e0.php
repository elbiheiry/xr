<?php if($paginator->hasPages()): ?>
    <div class="col-lg-12 col-md-12">
        <div class="pagination-area">
            
            <?php if($paginator->onFirstPage()): ?>
                <a class="prev page-numbers"><i class="ri-arrow-left-s-line"></i>
                </a>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="prev page-numbers"><i
                        class="ri-arrow-left-s-line"></i></a>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <a class="disabled" aria-disabled="true"><span><?php echo e($element); ?></span></a>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            
                            <span class="page-numbers current" aria-current="page"><?php echo e($page); ?></span>
                        <?php else: ?>
                            <a href="<?php echo e($url); ?>" class="page-numbers"><?php echo e($page); ?></a>
                            
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="next page-numbers"><i
                        class="ri-arrow-right-s-line"></i></a>
            <?php else: ?>
                <a class="disabled next page-numbers">
                    <i class="ri-arrow-right-s-line"></i>
                </a>
            <?php endif; ?>
            
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\xr\resources\views/vendor/pagination/default.blade.php ENDPATH**/ ?>