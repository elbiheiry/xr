<div class="sidebarModal modal right fade" id="sidebarModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-bs-dismiss="modal">
                <i class="ri-close-line"></i>
            </button>
            <div class="modal-body">
                <a href="<?php echo e(route('site.index')); ?>">
                    <img src="<?php echo e(surl('images/logo.png')); ?>" class="black-logo" alt="image" />
                </a>
                <div class="sidebar-content">
                    <h3><?php echo e(__('layouts.about')); ?></h3>
                    <p>
                        <?php echo e($settings->translate(app()->getLocale())->description); ?>

                    </p>
                    <div class="sidebar-btn">
                        <a href="" class="default-btn"><?php echo e(__('layouts.talk')); ?></a>
                    </div>
                </div>
                <div class="sidebar-contact-info">
                    <h3><?php echo e(__('layouts.contact')); ?></h3>
                    <ul class="info-list">
                        <li>
                            <i class="ri-phone-fill"></i>
                            <a href="tel:<?php echo e($settings->phone); ?>"> <?php echo e($settings->phone); ?></a>
                        </li>
                        <li>
                            <i class="ri-mail-line"></i>
                            <a href="mailto:<?php echo e($settings->email); ?>"><?php echo e($settings->email); ?></a>
                        </li>
                        <li>
                            <i class="ri-map-pin-line"></i> <?php echo e($settings->translate(app()->getLocale())->address); ?>

                        </li>
                    </ul>
                </div>
                <ul class="sidebar-social-list">
                    <?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e($link->link); ?>" target="_blank">
                                <?php echo $link->icon; ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="contact-form">
                    <h3><?php echo e(__('layouts.ready')); ?></h3>
                    <form id="contactForm" class="contact-form" method="post"
                        action="<?php echo e(route('site.contact.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="row">
                            <div class="col-lg-12 col-md-6">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control"
                                        placeholder="<?php echo e(__('form.name')); ?>" />
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6">
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control"
                                        placeholder="<?php echo e(__('form.email')); ?>" />
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <div class="form-group">
                                    <input type="text" name="phone" class="form-control"
                                        placeholder="<?php echo e(__('form.phone')); ?>" />
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <div class="form-group">
                                    <textarea name="message" class="form-control" cols="30" rows="6"
                                        placeholder="<?php echo e(__('form.message')); ?>..."></textarea>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 form-group">
                                <div class="g-recaptcha" data-sitekey="6Lf4diYgAAAAAJZx1TBAoJeybyVXeATgcT7AX4NY"
                                    style="width:100px;">
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <button type="submit" class="default-btn">
                                    <?php echo e(__('layouts.send')); ?><span></span>
                                </button>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->yieldPushContent('models'); ?>
<?php $__env->startPush('js'); ?>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script>
        $(document).on('submit', '.contact-form', function() {
            var form = $(this);
            var url = form.attr('action');
            var formData = new FormData(form[0]);
            form.find(":submit").attr('disabled', true).html(
                "<?php echo e(app()->getLocale() == 'en' ? 'Please wait' : 'برجاء الإنتظار'); ?> <span></span>");

            $.ajax({
                url: url,
                method: 'POST',
                dataType: 'json',
                data: formData,
                contentType: false,
                cache: false,
                processData: false,
                success: function(response) {
                    notification("success", response, "fas fa-check");
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                },
                error: function(jqXHR) {
                    var response = $.parseJSON(jqXHR.responseText);
                    notification("danger", response, "fas fa-times");
                    form.find(":submit").attr('disabled', false).html(
                        "<?php echo e(__('layouts.send')); ?> <span></span>");
                }
            });
            $.ajaxSetup({
                headers: {
                    'X-CSRF-Token': $('input[name="_token"]').val()
                }
            });
            return false;
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\xr\resources\views/site/layouts/models.blade.php ENDPATH**/ ?>