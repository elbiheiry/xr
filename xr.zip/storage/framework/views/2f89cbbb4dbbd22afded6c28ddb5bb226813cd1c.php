
<?php $__env->startSection('content'); ?>
    <!-- Page head ==========================================-->
    <div class="page-head">
        <i class="fa fa-list"></i>
        solutions
        <ul class="breadcrumb">
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    Dashboard</a>
            </li>
            <li class="active">solutions</li>
        </ul>
    </div>
    <!-- Page content ==========================================-->
    <div class="page-content">
        <div class="widget">
            <div class="widget-title"> solutions</div>
            <div class="widget-content">
                <form method="post" action="<?php echo e(route('admin.solutions.store')); ?>" class="ajax-form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>solution inner image </label>
                                <div class="uplaod-wrap">
                                    <input type='file' name="inner_image">
                                    <span class='path'></span>
                                    <span class='button'>Select File</span>
                                </div>
                            </div>
                            <span class="text-danger">Image dimensions should be : 1250 * 750
                            </span>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>solution outer image </label>
                                <div class="uplaod-wrap">
                                    <input type='file' name="outer_image">
                                    <span class='path'></span>
                                    <span class='button'>Select File</span>
                                </div>
                            </div>
                            <span class="text-danger">Image dimensions should be : 500 * 335
                            </span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label> solution title (EN)</label>
                                <input type="text" class="form-control" name="title_en" />
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label> solution title (AR)</label>
                                <input type="text" class="form-control" name="title_ar" />
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label> solution brief (EN)</label>
                                <textarea class="form-control" name="brief_en"></textarea>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label> solution brief (AR)</label>
                                <textarea class="form-control" name="brief_ar"></textarea>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label> solution content (EN) </label>
                                <textarea class="form-control tiny-editor" name="description_en"></textarea>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label> solution content (AR) </label>
                                <textarea class="form-control tiny-editor" name="description_ar"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <button class="custom-btn" type="submit">
                            Save Change <i class="fa fa-long-arrow-alt-right"></i>
                        </button>
                    </div>
                </form>
            </div>
            <!--End Widget-content-->
        </div>
    </div>
    <!--End Page content-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xr\resources\views/admin/pages/solutions/create.blade.php ENDPATH**/ ?>