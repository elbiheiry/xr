
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="widget">
            <div class="widget-content">
                <div class="row">
                    <div class="col-12">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="counter">
                                    <i class="fa fa-newspaper"></i>
                                    <div class="counter-cont">
                                        <h3 class="timer" data-to="<?php echo e(\App\Models\Article::count()); ?>"
                                            data-speed="1500">
                                            <?php echo e(\App\Models\Article::count()); ?>

                                        </h3>
                                        <div class="count-name">Articles</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="counter">
                                    <i class="fa fa-info"></i>
                                    <div class="counter-cont">
                                        <h3 class="timer" data-to="<?php echo e(\App\Models\Solution::count()); ?>"
                                            data-speed="1500">
                                            <?php echo e(\App\Models\Solution::count()); ?>

                                        </h3>
                                        <div class="count-name">Solutions</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="counter">
                                    <i class="fa fa-envelope"></i>
                                    <div class="counter-cont">
                                        <h3 class="timer" data-to="<?php echo e(\App\Models\Message::count()); ?>"
                                            data-speed="1500">
                                            <?php echo e(\App\Models\Message::count()); ?>

                                        </h3>
                                        <div class="count-name">Messages</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="counter">
                                    <i class="fa fa-users"></i>
                                    <div class="counter-cont">
                                        <h3 class="timer" data-to="<?php echo e(\App\Models\Subscriber::count()); ?>"
                                            data-speed="1500">
                                            <?php echo e(\App\Models\Subscriber::count()); ?>

                                        </h3>
                                        <div class="count-name">Subscribers</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="w-100"></div>
        <div class="row" style="margin: 0 -15px">
            <div class="col-lg-6">
                <div class="widget">
                    <div class="widget-title"> Latest Messages
                        <a href="<?php echo e(route('admin.messages.index')); ?>" class="custom-btn"> see all</a>
                    </div>
                    <div class="widget-content" style="padding: 0">
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item-list">
                                <a href="<?php echo e(route('admin.messages.show', ['id' => $message->id])); ?>">
                                    <img src="<?php echo e($message->image()); ?>" />
                                    <div class="item-content">
                                        <?php echo e($message->email); ?>

                                        <br />
                                        <span> <i class="fa fa-clock"></i> <?php echo e($message->created_at->diffForHumans()); ?>

                                        </span>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="widget">
                    <div class="widget-title"> Latest Subscribers
                        <a href="<?php echo e(route('admin.subscribers.index')); ?>" class="custom-btn"> see all</a>
                    </div>
                    <div class="widget-content" style="padding: 0">
                        <?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item-list">
                                <img src="<?php echo e($subscriber->image()); ?>" />
                                <div class="item-content">
                                    <?php echo e($subscriber->email); ?>

                                    <br />
                                    <span> <i class="fa fa-clock"></i> <?php echo e($subscriber->created_at->diffForHumans()); ?>

                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xr\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>