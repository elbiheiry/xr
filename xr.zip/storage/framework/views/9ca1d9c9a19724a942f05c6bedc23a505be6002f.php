<footer class="footer-area with-black-background pt-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-3 col-md-6">
                <div class="single-footer-widget" data-aos="fade-up" data-aos-delay="50" data-aos-duration="500"
                    data-aos-once="true">
                    <div class="widget-logo">
                        <a href="<?php echo e(route('site.index')); ?>"><img src="<?php echo e(surl('images/logo.png')); ?>"
                                alt="image" /></a>
                    </div>
                    <p>
                        <?php echo e($settings->translate(app()->getLocale())->description); ?>

                    </p>
                    <ul class="widget-social">
                        <?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e($link->link); ?>" target="_blank">
                                    <?php echo $link->icon; ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single-footer-widget ps-5" data-aos="fade-up" data-aos-delay="70" data-aos-duration="700"
                    data-aos-once="true">
                    <h3>XR <?php echo e(__('layouts.solutions')); ?></h3>
                    <ul class="quick-links">
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('site.solution', ['slug' => $service->slug])); ?>"><?php echo e($service->translate(app()->getLocale())->title); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single-footer-widget ps-5" data-aos="fade-up" data-aos-delay="60" data-aos-duration="600"
                    data-aos-once="true">
                    <h3><?php echo e(__('layouts.quick')); ?></h3>
                    <ul class="quick-links">
                        <li><a href="<?php echo e(route('site.about.index')); ?>"><?php echo e(__('layouts.who_we_are')); ?> </a></li>
                        <li><a href="<?php echo e(route('site.about.partners')); ?>"> <?php echo e(__('layouts.partners')); ?> </a></li>
                        <li><a href="<?php echo e(route('site.articles.index')); ?>"><?php echo e(__('layouts.articles')); ?> </a></li>
                        <li><a href="<?php echo e(route('site.team')); ?>"> <?php echo e(__('layouts.team')); ?></a></li>
                        <li><a href="<?php echo e(route('site.contact')); ?>"><?php echo e(__('layouts.contact_header')); ?></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single-footer-widget" data-aos="fade-up" data-aos-delay="80" data-aos-duration="800"
                    data-aos-once="true">
                    <h3><?php echo e(__('layouts.newsletter')); ?></h3>
                    <form class="newsletter-form" method="post" action="<?php echo e(route('site.subscribe')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <input type="email" class="input-newsletter" placeholder="<?php echo e(__('layouts.email')); ?>"
                            name="email" autocomplete="off" />
                        <button type="submit" class="default-btn"><?php echo e(__('layouts.subscribe')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-area">
        <div class="container">
            <div class="copyright-area-content">
                <?php if(app()->getLocale() == 'en'): ?>
                    <p>Copyright @ 2022 Newlevel XR All Rights Reserved</p>
                <?php else: ?>
                    <p>حقوق النشر @ 2022 Newlevel XR جميع الحقوق محفوظة</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</footer>
<?php $__env->startPush('js'); ?>
    <script>
        //submit form using ajax
        $(document).on('submit', '.newsletter-form', function() {
            var form = $(this);
            var url = form.attr('action');
            var formData = new FormData(form[0]);
            form.find(":submit").attr('disabled', true).html("<?php echo e(__('form.wait')); ?>");

            $.ajax({
                url: url,
                method: 'POST',
                dataType: 'json',
                data: formData,
                contentType: false,
                cache: false,
                processData: false,
                success: function(response) {
                    notification("success", response, "fas fa-check");
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                },
                error: function(jqXHR) {
                    var response = $.parseJSON(jqXHR.responseText);
                    notification("danger", response, "fas fa-times");
                    form.find(":submit").attr('disabled', false).html(
                        "<?php echo e(__('layouts.subscribe')); ?>");
                }
            });
            $.ajaxSetup({
                headers: {
                    'X-CSRF-Token': $('input[name="_token"]').val()
                }
            });
            return false;
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\xr\resources\views/site/layouts/footer.blade.php ENDPATH**/ ?>