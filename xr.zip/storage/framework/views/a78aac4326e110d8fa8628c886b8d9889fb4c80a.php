<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item-list gray">
        <a href="<?php echo e(route('admin.messages.show', ['id' => $message->id])); ?>">
            <img src="<?php echo e($message->image()); ?>" />
            <div class="item-content">
                <?php echo e($message->name); ?>

                <br />
                <span> <i class="fa fa-clock"></i> <?php echo e($message->created_at->diffForHumans()); ?> </span>
                <span> <i class="fa fa-envelope"></i> <?php echo e($message->email); ?> </span>
                <span> <i class="fa fa-phone"></i> <?php echo e($message->phone); ?> </span>
            </div>
        </a>
        <button class="icon-btn red-bc delete-btn"
            data-url="<?php echo e(route('admin.messages.delete', ['id' => $message->id])); ?>">
            <i class="fa fa-trash"></i>
        </button>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\xr\resources\views/admin/pages/messages/templates/messages.blade.php ENDPATH**/ ?>