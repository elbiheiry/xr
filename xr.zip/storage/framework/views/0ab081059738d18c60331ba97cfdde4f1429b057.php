
<?php $__env->startSection('content'); ?>
    <!-- Page head ==========================================-->
    <div class="page-head">
        <i class="fa fa-list"></i>
        Work process
        <ul class="breadcrumb">
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    Dashboard</a>
            </li>
            <li class="active">Work process</li>
        </ul>
    </div>
    <!-- Page content ==========================================-->
    <div class="page-content">
        <div class="widget">
            <div class="widget-title">
                Work process
                <a class="custom-btn" href="<?php echo e(route('admin.works.create')); ?>">
                    <i class="fa fa-plus"></i> Add step
                </a>
            </div>
            <div class="widget-content">
                <?php
                    $x = 1;
                ?>
                <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slide_item">
                        <div class="slide_cont">
                            <span> #<?php echo e($x); ?> </span>
                            <h3><?php echo e($work->translate('en')->title); ?></h3>
                            <div class="w-100">
                                <a class="custom-btn" href="<?php echo e(route('admin.works.edit', ['id' => $work->id])); ?>">
                                    <i class="fa fa-edit"></i> Edit
                                </a>
                                <button class="custom-btn red-bc delete-btn"
                                    data-url="<?php echo e(route('admin.works.delete', ['id' => $work->id])); ?>"
                                    style="margin-left:5px;">
                                    <i class="fa fa-trash-alt"></i> Delete
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php
                        $x++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

    </div>
    <!--End Page content-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xr\resources\views/admin/pages/works/index.blade.php ENDPATH**/ ?>