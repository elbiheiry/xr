
<?php $__env->startSection('content'); ?>
    <!-- Page head ==========================================-->
    <div class="page-head">
        <i class="fa fa-envelope"></i>
        Messages
        <ul class="breadcrumb">
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    Dashboard</a>
            </li>
            <li class="active">Messages</li>
        </ul>
    </div>
    <!-- Page content ==========================================-->
    <div class="page-content">
        <div class="widget">
            <div class="widget-title">
                <div class="alert-text">You have <?php echo e(\App\Models\Message::count()); ?> Message</div>
            </div>
            <!--End Widget Title-->
            <div class="widget-content">
                <div class="row">
                    <div class="col" id="load-area">
                        <?php echo $__env->make('admin.pages.messages.templates.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <!--End Item List-->
                    <div class="w-100"></div>
                    <?php if($messages->count() > 0): ?>
                        <button class="custom-btn" data-url="<?php echo e(url()->current()); ?>" id="load-more-button"
                            data-last="<?php echo e($messages->lastPage()); ?>" data-count="<?php echo e($messages->currentPage()); ?>">
                            Load More
                        </button>
                    <?php endif; ?>

                </div>
            </div>
            <!--End Widget-content-->
        </div>
        <!--End Widget-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xr\resources\views/admin/pages/messages/index.blade.php ENDPATH**/ ?>