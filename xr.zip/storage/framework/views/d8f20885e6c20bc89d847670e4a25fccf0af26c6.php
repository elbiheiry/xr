
<?php $__env->startSection('content'); ?>
    <div class="page-banner-area bg-2 jarallax" data-jarallax='{"speed": 0.3}'>
        <div class="container">
            <div class="page-banner-content" data-aos="fade-right" data-aos-delay="50" data-aos-duration="500"
                data-aos-once="true">
                <h2><?php echo e($article->translate(app()->getLocale())->title); ?></h2>

                <ul>
                    <li>
                        <a href="<?php echo e(route('site.index')); ?>"><?php echo e(__('layouts.home')); ?></a>
                    </li>
                    <li><?php echo e($article->translate(app()->getLocale())->title); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Page Banner Area -->

    <!-- Start Blog Details Area -->
    <div class="blog-details-area pt-100 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <div class="blog-details-desc">
                        <div class="article-image">
                            <img src="<?php echo e(get_image($article->inner_image, 'articles')); ?>" alt="image" />
                        </div>

                        <div class="article-content">
                            <ul class="entry-list">
                                <li><?php echo e(app()->getLocale() == 'en' ? 'By' : 'بواسطة'); ?> <a
                                        href="javascript:;"><?php echo e($article->created_by); ?></a></li>
                                <li><?php echo e($article->created_at->isoFormat('Do MMM, YYYY')); ?></li>
                            </ul>
                            <h3><?php echo e($article->translate(app()->getLocale())->title); ?></h3>
                            <?php echo $article->translate(app()->getLocale())->description; ?>

                        </div>

                        <div class="article-share">
                            <div class="row align-items-center">
                                <div class="col-lg-6 col-md-6">
                                    <div class="share-content">
                                        <h4><?php echo e(app()->getLocale() == 'en' ? 'Share The Article' : 'مشاركة المقال'); ?>:</h4>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <!-- AddToAny BEGIN -->

                                    <script async src="https://static.addtoany.com/menu/page.js"></script>
                                    <!-- AddToAny END -->
                                    <ul class="share-social text-end a2a_kit a2a_kit_size_32 a2a_default_style">
                                        <li>
                                            <a class="a2a_button_facebook"></a>
                                        </li>
                                        <li>
                                            <a class="a2a_button_twitter"></a>
                                        </li>
                                        <li>
                                            <a class="a2a_button_whatsapp"></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="article-comments">
                            <h3><?php echo e($article->comments->count()); ?>

                                <?php echo e(app()->getLocale() == 'en' ? 'Comments' : 'تعليقات'); ?>:</h3>

                            <?php $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="comments-list">
                                    <img src="<?php echo e($comment->user_image()); ?>" alt="image" />
                                    <h5><?php echo e($comment->name); ?>, <span><?php echo e($comment->created_at->diffForHumans()); ?></span>
                                    </h5>
                                    <p>
                                        <?php echo e($comment->comment); ?>

                                    </p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="article-leave-comment">
                            <h3><?php echo e(app()->getLocale() == 'en' ? 'Leave a reply' : 'إترك تعليقك'); ?></h3>

                            <form method="post" action="<?php echo e(route('site.articles.store', ['id' => $article->id])); ?>"
                                class="comment-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <div class="row justify-content-center">
                                    <div class="col-lg-6 col-md-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="name"
                                                placeholder="<?php echo e(__('form.name')); ?>" />
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-12">
                                        <div class="form-group">
                                            <input type="email" class="form-control"
                                                placeholder="<?php echo e(__('form.email')); ?>" name="email" />
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                            <textarea name="comment" class="form-control" placeholder="<?php echo e(__('form.message')); ?>"></textarea>
                                        </div>
                                    </div>

                                    <div class="col-lg-12 col-md-12">
                                        <button type="submit" class="default-btn">
                                            <?php echo e(app()->getLocale() == 'en' ? 'Post A Comment' : 'إترك تعليقك'); ?>

                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-12">
                    <aside class="widget-area">

                        <div class="widget widget_recent_post">
                            <h3 class="widget-title">
                                <?php echo e(app()->getLocale() == 'en' ? 'Recent Post' : 'المقالات الحالية'); ?></h3>

                            <?php $__currentLoopData = $related_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $realted_article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <article class="item">
                                    <a href="<?php echo e(route('site.articles.article', ['slug' => $realted_article->slug])); ?>"
                                        class="thumb">
                                        <span class="fullimage bg1" role="img"></span>
                                    </a>
                                    <div class="info">
                                        <span><?php echo e($realted_article->created_at->isoFormat('Do MMM, YYYY')); ?></span>
                                        <h4 class="title usmall">
                                            <a
                                                href="<?php echo e(route('site.articles.article', ['slug' => $realted_article->slug])); ?>">How
                                                <?php echo e($article->translate(app()->getLocale())->title); ?></a>
                                        </h4>
                                    </div>
                                </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </div>
    <!-- End Blog Details Area -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).on('submit', '.comment-form', function() {
            var form = $(this);
            var url = form.attr('action');
            var formData = new FormData(form[0]);
            form.find(":submit").attr('disabled', true).html(
                "<?php echo e(app()->getLocale() == 'en' ? 'Please wait' : 'برجاء الإنتظار'); ?> <span></span>");

            $.ajax({
                url: url,
                method: 'POST',
                dataType: 'json',
                data: formData,
                contentType: false,
                cache: false,
                processData: false,
                success: function(response) {
                    notification("success", response, "fas fa-check");
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                },
                error: function(jqXHR) {
                    var response = $.parseJSON(jqXHR.responseText);
                    notification("danger", response, "fas fa-times");
                    form.find(":submit").attr('disabled', false).html(
                        "<?php echo e(app()->getLocale() == 'en' ? 'Post A Comment' : 'إترك تعليقك'); ?>");
                }
            });
            $.ajaxSetup({
                headers: {
                    'X-CSRF-Token': $('input[name="_token"]').val()
                }
            });
            return false;
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xr\resources\views/site/pages/articles/article.blade.php ENDPATH**/ ?>