<header class="main-header-area">
    <!-- Start Navbar Area -->
    <div class="navbar-area">
        <div class="main-responsive-nav">
            <div class="container">
                <div class="main-responsive-menu">
                    <div class="logo">
                        <a href="<?php echo e(route('site.index')); ?>">
                            <img src="<?php echo e(surl('images/logo.png')); ?>" alt="image" />
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-navbar">
            <div class="container-fluid">
                <nav class="navbar navbar-expand-md navbar-light">
                    <a class="navbar-brand" href="<?php echo e(route('site.index')); ?>">
                        <img src="<?php echo e(surl('images/logo.png')); ?>" alt="image" />
                    </a>
                    <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item">
                                <a href="<?php echo e(route('site.index')); ?>"
                                    class="nav-link <?php echo e(request()->routeIs('site.index') ? 'active' : ''); ?>">
                                    <?php echo e(__('layouts.home')); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#"
                                    class="nav-link <?php echo e(request()->routeIs('site.about.index') || request()->routeIs('site.about.partners') ? 'active' : ''); ?>">
                                    <?php echo e(__('layouts.about')); ?>

                                    <i class="ri-arrow-down-s-line"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('site.about.index')); ?>" class="nav-link">
                                            <?php echo e(__('layouts.who_we_are')); ?></a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('site.about.partners')); ?>" class="nav-link">
                                            <?php echo e(__('layouts.partners')); ?></a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    XR <?php echo e(__('layouts.solutions')); ?>

                                    <i class="ri-arrow-down-s-line"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('site.solution', ['slug' => $service->slug])); ?>"
                                                class="nav-link"><?php echo e($service->translate(app()->getLocale())->title); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('site.articles.index')); ?>"
                                    class="nav-link <?php echo e(request()->routeIs('site.articles.index') || request()->routeIs('site.articles.article') ? 'active' : ''); ?>"><?php echo e(__('layouts.articles')); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('site.team')); ?>"
                                    class="nav-link <?php echo e(request()->routeIs('site.team') ? 'active' : ''); ?>"><?php echo e(__('layouts.team')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('site.contact')); ?>"
                                    class="nav-link <?php echo e(request()->routeIs('site.contact') ? 'active' : ''); ?>"><?php echo e(__('layouts.contact_header')); ?></a>
                            </li>
                            <li class="nav-item">
                                <?php if(app()->getLocale() == 'en'): ?>
                                    <a href="<?php echo e(LaravelLocalization::getLocalizedURL('ar')); ?>"
                                        class="lang nav-link"> AR </a>
                                <?php else: ?>
                                    <a href="<?php echo e(LaravelLocalization::getLocalizedURL('en')); ?>"
                                        class="lang nav-link"> EN </a>
                                <?php endif; ?>

                            </li>
                        </ul>
                        <div class="others-options d-flex align-items-center">
                            <div class="option-item">
                                <div class="side-menu-btn">
                                    <i class="ri-bar-chart-horizontal-line" data-bs-toggle="modal"
                                        data-bs-target="#sidebarModal"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <div class="others-option-for-responsive">
            <div class="container">
                <div class="dot-menu">
                    <div class="inner">
                        <div class="circle circle-one"></div>
                        <div class="circle circle-two"></div>
                        <div class="circle circle-three"></div>
                    </div>
                </div>
                <div class="container">
                    <div class="option-inner">
                        <div class="others-options d-flex align-items-center">
                            <div class="option-item">
                                <i class="search-btn ri-search-line"></i>
                                <i class="close-btn ri-close-line"></i>
                                <div class="search-overlay search-popup">
                                    <div class="search-box">
                                        <form class="search-form">
                                            <input class="search-input" placeholder="Search..." type="text" />
                                            <button class="search-button" type="submit">
                                                <i class="ri-search-line"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="option-item">
                                <div class="side-menu-btn">
                                    <i class="ri-bar-chart-horizontal-line" data-bs-toggle="modal"
                                        data-bs-target="#sidebarModal"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Navbar Area -->
</header>
<?php /**PATH C:\xampp\htdocs\xr\resources\views/site/layouts/header.blade.php ENDPATH**/ ?>