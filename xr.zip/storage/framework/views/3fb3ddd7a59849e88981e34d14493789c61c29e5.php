<?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item-list gray">
        <div class="item-content">
            <span> <i class="fa fa-clock"></i> <?php echo e($subscriber->created_at->diffForHumans()); ?> </span>
            <span> <i class="fa fa-envelope"></i> <?php echo e($subscriber->email); ?> </span>
        </div>
        <button class="icon-btn red-bc delete-btn"
            data-url="<?php echo e(route('admin.subscribers.delete', ['id' => $subscriber->id])); ?>">
            <i class="fa fa-trash"></i>
        </button>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\xr\resources\views/admin/pages/subscribers/templates/subscribers.blade.php ENDPATH**/ ?>