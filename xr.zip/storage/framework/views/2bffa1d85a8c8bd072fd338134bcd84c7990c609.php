
<?php $__env->startSection('content'); ?>
    <!-- Start Page Banner Area -->
    <div class="page-banner-area bg-4 jarallax" data-jarallax='{"speed": 0.3}'>
        <div class="container">
            <div class="page-banner-content" data-aos="fade-right" data-aos-delay="50" data-aos-duration="500"
                data-aos-once="true">
                <h2><?php echo e(__('layouts.articles')); ?></h2>

                <ul>
                    <li>
                        <a href="<?php echo e(route('site.index')); ?>"><?php echo e(__('layouts.home')); ?></a>
                    </li>
                    <li><?php echo e(__('layouts.articles')); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Page Banner Area -->

    <!-- Start Blog Area -->
    <div class="blog-area pt-100 pb-100">
        <div class="container">
            <div class="section-title">
                <span><?php echo e(__('layouts.articles')); ?></span>
                <h2>
                    <?php echo $content->translate(app()->getLocale())->title3; ?>

                    <span class="overlay"></span>
                </h2>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 col-md-12">
                        <div class="blog-card" data-aos="fade-up" data-aos-delay="<?php echo e($index % 2 == 0 ? '80' : '90'); ?>"
                            data-aos-duration="<?php echo e($index % 2 == 0 ? '800' : '900'); ?>" data-aos-once="true">
                            <div class="row align-items-center">
                                <div class="col-lg-6">
                                    <div class="blog-image">
                                        <a href="<?php echo e(route('site.articles.article', ['slug' => $article->slug])); ?>"><img
                                                src="<?php echo e(get_image($article->outer_image, 'articles')); ?>"
                                                alt="image" /></a>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="blog-content">
                                        <div class="date"><?php echo e($article->created_at->isoFormat('Do MMM, YYYY')); ?>

                                        </div>
                                        <h3>
                                            <a
                                                href="<?php echo e(route('site.articles.article', ['slug' => $article->slug])); ?>"><?php echo e($article->translate(app()->getLocale())->title); ?></a>
                                        </h3>
                                        <p>
                                            <?php echo e($article->translate(app()->getLocale())->brief); ?>

                                        </p>
                                        <a href="<?php echo e(route('site.articles.article', ['slug' => $article->slug])); ?>"
                                            class="blog-btn"><?php echo e(__('home.view')); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $articles->links('vendor.pagination.default'); ?>

                
            </div>
        </div>
    </div>
    <!-- End Blog Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xr\resources\views/site/pages/articles/index.blade.php ENDPATH**/ ?>