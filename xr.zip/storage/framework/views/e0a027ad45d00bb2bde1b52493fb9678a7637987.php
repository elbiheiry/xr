
<?php $__env->startSection('content'); ?>
    <!-- Page head ==========================================-->
    <div class="page-head">
        <i class="fa fa-list"></i>
        Solutions
        <ul class="breadcrumb">
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    Dashboard</a>
            </li>
            <li class="active">Solutions</li>
        </ul>
    </div>
    <!-- Page content ==========================================-->
    <div class="page-content">
        <div class="widget">
            <div class="widget-title">
                Solutions
                <a class="custom-btn" href="<?php echo e(route('admin.solutions.create')); ?>">
                    <i class="fa fa-plus"></i> Add solution
                </a>
            </div>
            <div class="widget-content">
                <?php
                    $x = 1;
                ?>
                <?php $__currentLoopData = $solutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $solution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slide_item">
                        <img src="<?php echo e(get_image($solution->inner_image, 'solutions')); ?>" />
                        <div class="slide_cont">
                            <span> #<?php echo e($x); ?> </span>
                            <h3><?php echo e($solution->translate('en')->title); ?></h3>
                            <div class="w-100">
                                <a class="custom-btn"
                                    href="<?php echo e(route('admin.solutions.edit', ['id' => $solution->id])); ?>">
                                    <i class="fa fa-edit"></i> Edit
                                </a>
                                <button class="custom-btn red-bc delete-btn"
                                    data-url="<?php echo e(route('admin.solutions.delete', ['id' => $solution->id])); ?>"
                                    style="margin-left:5px;">
                                    <i class="fa fa-trash-alt"></i> Delete
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php
                        $x++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

    </div>
    <!--End Page content-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xr\resources\views/admin/pages/solutions/index.blade.php ENDPATH**/ ?>